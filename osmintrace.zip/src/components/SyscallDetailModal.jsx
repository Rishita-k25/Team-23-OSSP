import React from 'react';
import { X, Cpu, Info, CheckCircle2, AlertOctagon, Clock } from 'lucide-react';
import StatusBadge from './StatusBadge';

const SYSCALL_DOCS = {
  read: 'Reads up to count bytes from file descriptor into the buffer starting at buf.',
  write: 'Writes up to count bytes from the buffer starting at buf to the file descriptor.',
  open: 'Opens the file specified by pathname. Returns a new file descriptor or negative error code.',
  openat: 'Opens the file specified by pathname relative to dirfd. Standard POSIX call used by modern glibc.',
  close: 'Closes a file descriptor, so that it no longer refers to any file and may be reused.',
  fstat: 'Retrieves status information about an open file descriptor into a struct stat buffer.',
  newfstatat: 'Retrieves file status relative to a directory file descriptor.',
  mmap: 'Creates a new virtual memory mapping in the calling process\'s address space.',
  mprotect: 'Sets memory protection (read/write/exec) on a region of virtual memory.',
  munmap: 'Unmaps a previously mapped memory region in the process address space.',
  brk: 'Changes the location of the program break, which defines the end of the process data segment (heap).',
  access: 'Checks whether the calling process can access the file pathname with specified permissions.',
  execve: 'Executes the program pointed to by filename. Replaces current process memory with the new program.',
  exit_group: 'Terminates all threads in the calling process and returns an exit code to the parent.',
  exit: 'Terminates the calling thread.',
  getpid: 'Returns the process ID (PID) of the calling process.',
  clone: 'Creates a new child process or thread, allowing fine-grained sharing of resources.',
  clone3: 'Modern extensible Linux interface for process and thread creation.',
  fork: 'Creates a new child process by duplicating the calling process.',
  wait4: 'Waits for state changes in a child of the calling process and obtains system resource usage info.',
  arch_prctl: 'Sets architecture-specific process or thread state (e.g., FS/GS base register).',
  set_tid_address: 'Sets the pointer to the thread ID for clean exit notification.',
  set_robust_list: 'Sets the list of robust futexes owned by the calling thread.',
  rseq: 'Restartable sequences: user-space per-CPU critical sections without locks.',
  prlimit64: 'Gets or sets resource limits of an arbitrary process.',
};

export default function SyscallDetailModal({ record, onClose }) {
  if (!record) return null;

  const regNames = ['rdi (arg0)', 'rsi (arg1)', 'rdx (arg2)', 'r10 (arg3)', 'r8 (arg4)', 'r9 (arg5)'];
  const args = record.args || [];
  const durationUs = (record.duration_ns / 1000).toFixed(2);
  const doc = SYSCALL_DOCS[record.name] || 'Standard Linux x86-64 system call.';

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        {/* Modal Header */}
        <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', backgroundColor: 'rgba(56, 189, 248, 0.15)', color: '#38bdf8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Cpu size={22} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 700, fontFamily: 'var(--font-mono)', color: '#38bdf8' }}>
                  {record.name}
                </h2>
                <span className="badge badge-cyan">#{record.syscall_nr}</span>
                <StatusBadge isError={record.is_error} />
              </div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Sequence #{record.index} &bull; Process PID: {record.pid}
              </div>
            </div>
          </div>

          <button 
            className="btn btn-outline" 
            style={{ padding: '6px', borderRadius: '50%' }}
            onClick={onClose}
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Syscall description */}
          <div style={{ backgroundColor: 'var(--bg-elevated)', padding: '14px 16px', borderRadius: '10px', borderLeft: '4px solid #38bdf8' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8rem', fontWeight: 600, color: '#38bdf8', marginBottom: '4px' }}>
              <Info size={14} />
              <span>Kernel Call Semantics</span>
            </div>
            <p style={{ fontSize: '0.86rem', color: 'var(--text-main)', lineHeight: 1.5 }}>
              {doc}
            </p>
          </div>

          {/* Quick Metrics */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
            <div style={{ backgroundColor: 'var(--bg-input)', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Return Value (rax)</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 700, fontFamily: 'var(--font-mono)', color: record.is_error ? '#fb7185' : '#34d399', marginTop: '2px' }}>
                {record.retval} {record.is_error ? '(Error)' : ''}
              </div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-input)', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Observed Duration</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--text-main)', marginTop: '2px' }}>
                {durationUs} <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>µs</span>
              </div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-input)', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Elapsed (ns)</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--text-main)', marginTop: '2px' }}>
                {record.duration_ns.toLocaleString()} <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>ns</span>
              </div>
            </div>
          </div>

          {/* Register Arguments */}
          <div>
            <div style={{ fontSize: '0.88rem', fontWeight: 700, marginBottom: '10px', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span>x86-64 System V AMD64 ABI Register State</span>
              <span className="badge badge-muted">PTRACE_GETREGS</span>
            </div>

            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Register</th>
                    <th>Hex Value</th>
                    <th>Decimal Value</th>
                    <th>Note</th>
                  </tr>
                </thead>
                <tbody>
                  {regNames.map((name, i) => {
                    const val = args[i] !== undefined ? args[i] : 0;
                    const hexVal = '0x' + (Number(val) >>> 0).toString(16).padStart(8, '0');
                    return (
                      <tr key={name}>
                        <td style={{ fontFamily: 'var(--font-mono)', color: '#38bdf8', fontWeight: 600 }}>{name}</td>
                        <td style={{ fontFamily: 'var(--font-mono)' }}>{hexVal}</td>
                        <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{val}</td>
                        <td style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                          {val === 0 ? 'NULL / Zero' : (val > 10000 ? 'Pointer / Memory address' : 'Descriptor / Flag')}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p style={{ fontSize: '0.74rem', color: 'var(--text-dim)', marginTop: '8px', fontStyle: 'italic' }}>
              * High integer values represent 64-bit user-space memory pointers in the child process virtual address space.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'flex-end', backgroundColor: 'var(--bg-elevated)' }}>
          <button className="btn btn-secondary" onClick={onClose}>
            Close Inspection
          </button>
        </div>
      </div>
    </div>
  );
}
