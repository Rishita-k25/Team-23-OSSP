import React from 'react';
import { 
  LayoutDashboard, 
  PlayCircle, 
  Search, 
  BarChart3, 
  FileClock, 
  BookOpen, 
  Terminal, 
  Cpu,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

export default function Sidebar({ activePage, setActivePage, health }) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'run', label: 'Run Trace', icon: PlayCircle },
    { id: 'explorer', label: 'Syscall Explorer', icon: Search },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'history', label: 'Trace History', icon: FileClock },
    { id: 'about', label: 'About & Docs', icon: BookOpen },
  ];

  return (
    <aside className="sidebar">
      <div className="brand-section">
        <div className="brand-icon">
          <Terminal size={24} />
        </div>
        <div>
          <div className="brand-title">SysTrace</div>
          <div className="brand-subtitle">MINI STRACE MONITOR</div>
        </div>
      </div>

      <nav className="nav-menu">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              className={`nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setActivePage(item.id)}
            >
              <Icon size={18} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="sidebar-status-box">
        <div className="status-indicator">
          <span className={`dot ${health ? '' : 'offline'}`} />
          <span>{health ? 'Backend Connected' : 'Connecting (Port 8000)...'}</span>
        </div>
        <div style={{ color: 'var(--text-muted)', fontSize: '0.74rem', marginTop: '4px' }}>
          <div>Engine: <span style={{ color: '#38bdf8' }}>Linux ptrace()</span></div>
          <div>Tracer: <span style={{ color: health?.tracer_available ? '#34d399' : '#f43f5e' }}>
            {health ? (health.tracer_available ? 'Compiled (Ready)' : 'Not Found (make clean all)') : 'Awaiting Backend'}
          </span></div>
          <div>Host: <span style={{ color: 'var(--text-main)' }}>{health?.environment || 'Ubuntu WSL2'}</span></div>
        </div>
      </div>
    </aside>
  );
}
