import React from 'react';
import { CheckCircle2, XCircle, AlertCircle, HelpCircle } from 'lucide-react';

export default function StatusBadge({ status, isError, text }) {
  if (isError !== undefined) {
    if (isError) {
      return (
        <span className="badge badge-danger">
          <XCircle size={12} />
          {text || 'Error'}
        </span>
      );
    }
    return (
      <span className="badge badge-success">
        <CheckCircle2 size={12} />
        {text || 'Success'}
      </span>
    );
  }

  if (status === 'FINISHED' || status === 'COMPLETED' || status === 'healthy') {
    return (
      <span className="badge badge-success">
        <CheckCircle2 size={12} />
        {text || status}
      </span>
    );
  }

  if (status === 'INCOMPLETE' || status === 'FAILED') {
    return (
      <span className="badge badge-danger">
        <XCircle size={12} />
        {text || status}
      </span>
    );
  }

  return (
    <span className="badge badge-cyan">
      <AlertCircle size={12} />
      {text || status}
    </span>
  );
}
