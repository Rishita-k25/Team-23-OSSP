import React from 'react';
import { Activity, Play, Terminal } from 'lucide-react';

export default function Navbar({ activePage, currentTrace, onStartTraceClick }) {
  const pageTitles = {
    dashboard: { title: 'System Dashboard', desc: 'Real-time telemetry and overview of ptrace system call observations' },
    run: { title: 'Launch Process Trace', desc: 'Select an approved Linux executable and trace system call entry/exit in real time' },
    explorer: { title: 'System Call Explorer', desc: 'Inspect, filter, search, and decode captured x86-64 syscall arguments and return values' },
    analytics: { title: 'Syscall Analytics & Metrics', desc: 'Distribution charts, frequency trends, and error ratios calculated from real traces' },
    history: { title: 'Trace History & Reports', desc: 'Review completed runs, view detailed reports, and export to CSV or JSONL' },
    about: { title: 'Academic Documentation & Viva Guide', desc: 'In-depth explanation of Linux kernel interfaces, ptrace(), fork, and process coordination' },
  };

  const info = pageTitles[activePage] || { title: 'SysTrace', desc: '' };

  return (
    <header className="top-navbar">
      <div className="page-info">
        <h1>{info.title}</h1>
        <p>{info.desc}</p>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
        {currentTrace && (
          <div className="active-trace-pill">
            <Activity size={14} style={{ color: '#34d399' }} />
            <span>Active: {currentTrace.program_name}</span>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.72rem' }}>
              ({currentTrace.summary.total_calls} calls)
            </span>
          </div>
        )}

        {activePage !== 'run' && (
          <button className="btn btn-primary" onClick={onStartTraceClick}>
            <Play size={16} fill="currentColor" />
            <span>New Trace</span>
          </button>
        )}
      </div>
    </header>
  );
}
