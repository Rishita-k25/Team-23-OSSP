// Support Vite proxy (/api) by default, or an explicitly configured backend URL
const API_BASE = import.meta.env.VITE_API_URL || "/api";

async function handleFetchError(res, defaultMsg) {
  let detail = defaultMsg;
  try {
    const errorData = await res.json();
    if (errorData && errorData.detail) {
      detail = errorData.detail;
    }
  } catch {
    // Non-JSON response
  }
  return new Error(detail);
}

export async function fetchHealth() {
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw await handleFetchError(res, "Backend health check failed");
    return await res.json();
  } catch (err) {
    if (err.name === 'TypeError') {
      throw new Error("Cannot connect to SysTrace backend service at http://127.0.0.1:8000.");
    }
    throw err;
  }
}

export async function fetchPrograms() {
  try {
    const res = await fetch(`${API_BASE}/programs`);
    if (!res.ok) throw await handleFetchError(res, "Failed to load approved programs");
    return await res.json();
  } catch (err) {
    if (err.name === 'TypeError') {
      throw new Error("Cannot connect to SysTrace backend service at http://127.0.0.1:8000.");
    }
    throw err;
  }
}

export async function startTrace(programId) {
  try {
    const res = await fetch(`${API_BASE}/traces`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ program_id: programId }),
    });
    if (!res.ok) {
      throw await handleFetchError(res, `Trace execution failed with HTTP ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    if (err.name === 'TypeError') {
      throw new Error("Cannot connect to SysTrace backend service at http://127.0.0.1:8000.");
    }
    throw err;
  }
}

export async function fetchTraces() {
  try {
    const res = await fetch(`${API_BASE}/traces`);
    if (!res.ok) throw await handleFetchError(res, "Failed to load trace history");
    return await res.json();
  } catch (err) {
    if (err.name === 'TypeError') {
      throw new Error("Cannot connect to SysTrace backend service at http://127.0.0.1:8000.");
    }
    throw err;
  }
}

export async function fetchTrace(traceId) {
  try {
    const res = await fetch(`${API_BASE}/traces/${traceId}`);
    if (!res.ok) throw await handleFetchError(res, `Failed to load trace ${traceId}`);
    return await res.json();
  } catch (err) {
    if (err.name === 'TypeError') {
      throw new Error("Cannot connect to SysTrace backend service at http://127.0.0.1:8000.");
    }
    throw err;
  }
}

export function getExportCsvUrl(traceId) {
  return `${API_BASE}/traces/${traceId}/export?format=csv`;
}

export function getExportJsonlUrl(traceId) {
  return `${API_BASE}/traces/${traceId}/export?format=jsonl`;
}
