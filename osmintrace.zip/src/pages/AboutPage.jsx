import React, { useState } from 'react';
import { 
  BookOpen, 
  Cpu, 
  Terminal, 
  Layers, 
  GitBranch, 
  ShieldCheck, 
  HelpCircle,
  GraduationCap,
  Code
} from 'lucide-react';

export default function AboutPage() {
  const [activeSection, setActiveSection] = useState('arch');

  const sections = [
    { id: 'arch', label: '1. Linux ptrace Architecture' },
    { id: 'flow', label: '2. Process Coordination Flow' },
    { id: 'abi', label: '3. x86-64 Register Conventions' },
    { id: 'viva', label: '4. Academic Viva & OS Lab Guide' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header Banner */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <span className="badge badge-cyan">Operating Systems Course Project</span>
              <span className="badge badge-success">CSE Department</span>
            </div>
            <h2 style={{ fontSize: '1.45rem', fontWeight: 800 }}>
              Mini strace-Like Process Monitoring Tool — Technical Documentation
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginTop: '4px' }}>
              Comprehensive engineering reference, kernel system-call mechanisms, and viva presentation notes.
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <GraduationCap size={32} style={{ color: '#38bdf8' }} />
          </div>
        </div>

        {/* Section Tabs */}
        <div style={{ display: 'flex', gap: '8px', marginTop: '20px', borderTop: '1px solid var(--border-subtle)', paddingTop: '16px', flexWrap: 'wrap' }}>
          {sections.map((sec) => (
            <button
              key={sec.id}
              className={`btn ${activeSection === sec.id ? 'btn-secondary' : 'btn-outline'}`}
              style={{ 
                borderColor: activeSection === sec.id ? '#38bdf8' : 'var(--border-subtle)',
                color: activeSection === sec.id ? '#38bdf8' : 'var(--text-muted)',
                fontSize: '0.84rem'
              }}
              onClick={() => setActiveSection(sec.id)}
            >
              {sec.label}
            </button>
          ))}
        </div>
      </div>

      {/* Section 1: Architecture */}
      {activeSection === 'arch' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="card">
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#38bdf8', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Cpu size={20} />
              <span>What Are Linux System Calls and Why Trace Them?</span>
            </h3>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-main)', lineHeight: 1.6, marginBottom: '14px' }}>
              Modern operating systems enforce a strict hardware separation between <strong>User Mode</strong> (Ring 3) 
              and <strong>Kernel Mode</strong> (Ring 0). User programs cannot directly access hardware devices, network interfaces, 
              or physical storage. Instead, they must request operating system services through <strong>System Calls (syscalls)</strong>.
            </p>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>
              On x86-64 Linux, user applications execute the <code className="font-mono" style={{ color: '#38bdf8' }}>syscall</code> instruction. 
              The CPU switches to Ring 0, saves the instruction pointer, and jumps to the kernel's system call entry point 
              (<code className="font-mono">entry_SYSCALL_64</code>). The kernel performs the requested action (e.g. <code className="font-mono">read</code>, <code className="font-mono">write</code>, <code className="font-mono">openat</code>) 
              and returns the result back to user space via <code className="font-mono">sysret</code>.
            </p>
          </div>

          <div className="card">
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#10b981', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Layers size={20} />
              <span>The Role of ptrace() in This Project</span>
            </h3>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-main)', lineHeight: 1.6, marginBottom: '12px' }}>
              The <code className="font-mono" style={{ color: '#38bdf8' }}>ptrace()</code> (Process Trace) system call is the primary debugging mechanism in Linux. 
              In our project, the C tracer establishes control over the target program using four core operations:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '14px', marginTop: '14px' }}>
              <div style={{ backgroundColor: 'var(--bg-input)', padding: '16px', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontFamily: 'var(--font-mono)', fontSize: '0.9rem', marginBottom: '6px' }}>
                  PTRACE_TRACEME
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  Called by the child process immediately after <code className="font-mono">fork()</code>. It indicates that this child is willing to be traced by its parent process.
                </p>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '16px', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontFamily: 'var(--font-mono)', fontSize: '0.9rem', marginBottom: '6px' }}>
                  PTRACE_SETOPTIONS
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  Sets <code className="font-mono">PTRACE_O_TRACESYSGOOD</code>. This causes the kernel to deliver signal <code className="font-mono">(SIGTRAP | 0x80)</code> on syscall traps, allowing the tracer to distinguish syscall stops from normal traps.
                </p>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '16px', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontFamily: 'var(--font-mono)', fontSize: '0.9rem', marginBottom: '6px' }}>
                  PTRACE_SYSCALL
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  Resumes the stopped child process and configures the kernel to stop it again at the very next system-call entry or exit.
                </p>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '16px', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontFamily: 'var(--font-mono)', fontSize: '0.9rem', marginBottom: '6px' }}>
                  PTRACE_GETREGS
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  Copies the target process's CPU registers into <code className="font-mono">struct user_regs_struct</code>, revealing arguments and return values.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section 2: Flow */}
      {activeSection === 'flow' && (
        <div className="card">
          <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#38bdf8', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <GitBranch size={20} />
            <span>Process Coordination & Syscall Entry/Exit Alternation</span>
          </h3>

          <p style={{ fontSize: '0.9rem', color: 'var(--text-main)', lineHeight: 1.6, marginBottom: '16px' }}>
            For each system call, the kernel generates <strong>two distinct stops</strong>:
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={{ padding: '16px', borderRadius: '10px', backgroundColor: 'var(--bg-input)', borderLeft: '4px solid #38bdf8' }}>
              <div style={{ fontWeight: 700, color: '#38bdf8', marginBottom: '4px' }}>1. Syscall Entry Trap</div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                The target process is paused just before executing the kernel function. At this moment:
                <br />&bull; Register <code className="font-mono" style={{ color: '#f8fafc' }}>orig_rax</code> contains the system call number (e.g. 1 for write, 257 for openat).
                <br />&bull; Registers <code className="font-mono" style={{ color: '#f8fafc' }}>rdi, rsi, rdx, r10, r8, r9</code> contain the incoming parameters.
                <br />&bull; The tracer records the syscall name and records the entry timestamp with <code className="font-mono">clock_gettime(CLOCK_MONOTONIC)</code>.
              </p>
            </div>

            <div style={{ padding: '16px', borderRadius: '10px', backgroundColor: 'var(--bg-input)', borderLeft: '4px solid #10b981' }}>
              <div style={{ fontWeight: 700, color: '#10b981', marginBottom: '4px' }}>2. Syscall Exit Trap</div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                The target process is paused immediately after the kernel has finished executing the service. At this moment:
                <br />&bull; Register <code className="font-mono" style={{ color: '#f8fafc' }}>rax</code> contains the function return value.
                <br />&bull; If <code className="font-mono">rax</code> is in range <code className="font-mono">-4095 ... -1</code>, it represents a negated Linux error code (e.g., <code className="font-mono">-2 = -ENOENT</code>).
                <br />&bull; The tracer computes <code className="font-mono">duration_ns = exit_time - entry_time</code> and emits the complete event record.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Section 3: ABI */}
      {activeSection === 'abi' && (
        <div className="card">
          <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#38bdf8', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Terminal size={20} />
            <span>x86-64 System V AMD64 ABI Register Mapping</span>
          </h3>

          <p style={{ fontSize: '0.9rem', color: 'var(--text-main)', lineHeight: 1.6, marginBottom: '16px' }}>
            Unlike 32-bit x86 (which used interrupt <code className="font-mono">int 0x80</code> and <code className="font-mono">ebx, ecx, edx</code>), 
            64-bit Linux uses the dedicated <code className="font-mono">syscall</code> assembly instruction and the AMD64 ABI registers:
          </p>

          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Field / Purpose</th>
                  <th>x86-64 Register</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ fontWeight: 600, color: '#38bdf8' }}>Syscall Number</td>
                  <td className="font-mono">orig_rax</td>
                  <td>Kernel system call identifier (e.g., 0=read, 1=write, 9=mmap, 257=openat)</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>Argument 0</td>
                  <td className="font-mono">rdi</td>
                  <td>First parameter (e.g., file descriptor or memory address)</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>Argument 1</td>
                  <td className="font-mono">rsi</td>
                  <td>Second parameter (e.g., buffer pointer or flags)</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>Argument 2</td>
                  <td className="font-mono">rdx</td>
                  <td>Third parameter (e.g., buffer byte length or permissions mode)</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>Argument 3</td>
                  <td className="font-mono">r10</td>
                  <td>Fourth parameter (Note: r10 is used because rcx is destroyed by syscall instruction)</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>Argument 4</td>
                  <td className="font-mono">r8</td>
                  <td>Fifth parameter</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>Argument 5</td>
                  <td className="font-mono">r9</td>
                  <td>Sixth parameter</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: '#34d399' }}>Return Value</td>
                  <td className="font-mono">rax</td>
                  <td>Return code from kernel. Negative values between -4095 and -1 designate errno codes.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section 4: Viva Guide */}
      {activeSection === 'viva' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="card" style={{ borderColor: '#38bdf8' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#38bdf8', marginBottom: '8px' }}>
              Academic Project Credits & Team Identification
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px', marginTop: '12px' }}>
              <div style={{ backgroundColor: 'var(--bg-input)', padding: '14px', borderRadius: '8px' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>STUDENT 1</div>
                <div style={{ fontWeight: 700, fontSize: '1rem', color: '#f8fafc' }}>P. Bhavana Manaswini</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem', color: '#38bdf8' }}>Reg: 2520030154</div>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '14px', borderRadius: '8px' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>STUDENT 2</div>
                <div style={{ fontWeight: 700, fontSize: '1rem', color: '#f8fafc' }}>K. Rishitha</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem', color: '#38bdf8' }}>Reg: 2520030367</div>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '14px', borderRadius: '8px' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>PROJECT DETAILS</div>
                <div style={{ fontWeight: 700, fontSize: '0.92rem', color: '#f8fafc' }}>Team 23 &bull; Section 9</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>Guide: Dr. Y. Harika Devi</div>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#10b981', marginBottom: '14px' }}>
              Common Viva Questions & Ready Answers
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={{ backgroundColor: 'var(--bg-input)', padding: '14px 18px', borderRadius: '10px' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontSize: '0.9rem', marginBottom: '6px' }}>
                  Q1: Why does ptrace stop twice for every system call?
                </div>
                <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  <strong>Answer:</strong> The first stop occurs on <em>syscall entry</em> before kernel execution, allowing inspection or modification of arguments in <code className="font-mono">rdi..r9</code>. The second stop occurs on <em>syscall exit</em> after kernel execution, allowing inspection of the return value in <code className="font-mono">rax</code>.
                </p>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '14px 18px', borderRadius: '10px' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontSize: '0.9rem', marginBottom: '6px' }}>
                  Q2: How does the tracer know if a system call failed without examining errno in user space?
                </div>
                <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  <strong>Answer:</strong> In the Linux kernel, negative return values between <code className="font-mono">-4095</code> and <code className="font-mono">-1</code> represent negated error numbers (<code className="font-mono">-errno</code>). The C library wrapper usually stores this value into user-space <code className="font-mono">errno</code> and returns -1, but at the raw syscall level in <code className="font-mono">rax</code>, the exact negated errno is visible directly to <code className="font-mono">PTRACE_GETREGS</code>.
                </p>
              </div>

              <div style={{ backgroundColor: 'var(--bg-input)', padding: '14px 18px', borderRadius: '10px' }}>
                <div style={{ fontWeight: 700, color: '#38bdf8', fontSize: '0.9rem', marginBottom: '6px' }}>
                  Q3: Why can't we just dereference string pointer arguments directly from the tracer?
                </div>
                <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  <strong>Answer:</strong> Due to virtual memory protection, the address space of the child process is isolated from the parent tracer. A pointer value (e.g. <code className="font-mono">0x7ffd98...</code>) is only valid in the child's page table. To read strings across memory boundaries in Linux, one must use <code className="font-mono">ptrace(PTRACE_PEEKDATA)</code> or <code className="font-mono">process_vm_readv()</code>. Our tracer displays the exact 64-bit numeric register without fabricating fake decoded paths.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
