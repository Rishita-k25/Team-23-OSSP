import React, { useState } from 'react';
import { 
  Play, 
  Loader2, 
  CheckCircle2, 
  AlertTriangle, 
  Terminal, 
  Layers, 
  Cpu, 
  ArrowRight,
  FileText,
  Clock,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

export default function RunTracePage({ 
  health,
  programs = [], 
  onRunTrace, 
  loading, 
  error, 
  lastRunResult, 
  onNavigate,
  onRefresh
}) {
  const [selectedProgId, setSelectedProgId] = useState('hello_world');
  const [activeTab, setActiveTab] = useState('output'); // 'output' or 'terminal'

  const selectedProgram = programs.find((p) => p.id === selectedProgId) || programs[0];

  const handleStartTrace = () => {
    const progId = selectedProgram?.id || selectedProgId;
    if (progId && onRunTrace) {
      onRunTrace(progId);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      {/* Backend Disconnected Warning */}
      {!health && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', padding: '14px 18px', borderRadius: '10px', color: '#f87171', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <AlertTriangle size={18} />
            <span style={{ fontSize: '0.88rem' }}>
              <strong>SysTrace backend is not connected.</strong> Ensure the FastAPI server is running with <code className="font-mono" style={{ color: '#38bdf8' }}>python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000</code>.
            </span>
          </div>
          {onRefresh && (
            <button className="btn btn-outline" style={{ padding: '6px 12px', fontSize: '0.8rem', borderColor: '#f87171', color: '#f87171' }} onClick={onRefresh}>
              <RefreshCw size={14} /> Retry Connection
            </button>
          )}
        </div>
      )}

      {/* Top Configuration & Launcher */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">
              <Play size={18} style={{ color: '#38bdf8' }} />
              <span>Select Approved Linux Program</span>
            </div>
            <div className="card-subtitle">
              Choose from security-vetted C binaries compiled under Ubuntu WSL2
            </div>
          </div>
          <span className="badge badge-cyan">Allowlist Enforced</span>
        </div>

        {programs.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-muted)' }}>
            <Cpu size={36} style={{ opacity: 0.4, marginBottom: '12px' }} />
            <div style={{ fontWeight: 600, color: 'var(--text-main)' }}>No Approved Programs Available</div>
            <p style={{ fontSize: '0.84rem', marginTop: '6px', maxWidth: '500px', margin: '6px auto 16px' }}>
              The program list could not be retrieved from the backend. Make sure the FastAPI service is active.
            </p>
            {onRefresh && (
              <button className="btn btn-primary" onClick={onRefresh}>
                <RefreshCw size={14} /> Reload Programs
              </button>
            )}
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '14px', marginBottom: '22px' }}>
            {programs.map((prog) => {
              const isSelected = prog.id === (selectedProgram?.id || selectedProgId);
              return (
                <div
                  key={prog.id}
                  onClick={() => setSelectedProgId(prog.id)}
                  style={{
                    padding: '16px',
                    borderRadius: '12px',
                    backgroundColor: isSelected ? 'var(--bg-elevated)' : 'var(--bg-input)',
                    border: isSelected ? '2px solid #38bdf8' : '1px solid var(--border-subtle)',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    boxShadow: isSelected ? '0 0 15px rgba(56, 189, 248, 0.25)' : 'none',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <span className="badge badge-muted" style={{ fontSize: '0.7rem' }}>{prog.category}</span>
                    {isSelected && <Sparkles size={14} style={{ color: '#38bdf8' }} />}
                  </div>
                  <div style={{ fontWeight: 700, fontSize: '0.98rem', color: isSelected ? '#38bdf8' : 'var(--text-main)', marginBottom: '4px' }}>
                    {prog.name}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', lineHeight: 1.4 }}>
                    {prog.description.slice(0, 70)}...
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Selected Program Detailed Spec */}
        {selectedProgram && (
          <div style={{ backgroundColor: 'var(--bg-input)', padding: '18px', borderRadius: '12px', border: '1px solid var(--border-subtle)', marginBottom: '22px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '14px' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '1.05rem', color: 'var(--text-main)', marginBottom: '4px' }}>
                  {selectedProgram.name} &bull; <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{selectedProgram.category}</span>
                </div>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.86rem', maxWidth: '800px', lineHeight: 1.5 }}>
                  {selectedProgram.description}
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '12px', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', fontWeight: 600 }}>Expected Syscalls:</span>
                  {selectedProgram.expected_syscalls.map((sc) => (
                    <span key={sc} className="badge badge-cyan" style={{ fontSize: '0.72rem' }}>
                      {sc}()
                    </span>
                  ))}
                </div>
              </div>

              <button
                className="btn btn-primary"
                style={{ padding: '12px 28px', fontSize: '1rem', minWidth: '180px' }}
                onClick={handleStartTrace}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 size={18} className="spin" style={{ animation: 'spin 1s linear infinite' }} />
                    <span>Tracing Syscalls...</span>
                  </>
                ) : (
                  <>
                    <Play size={18} fill="currentColor" />
                    <span>Start Trace</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Error notification */}
        {error && (
          <div style={{ backgroundColor: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '14px 18px', borderRadius: '10px', color: '#fb7185', display: 'flex', alignItems: 'center', gap: '12px', marginTop: '10px' }}>
            <AlertTriangle size={18} />
            <div style={{ fontSize: '0.86rem' }}>{error}</div>
          </div>
        )}
      </div>

      {/* Result Panel */}
      {lastRunResult && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Quick Metrics Bar */}
          <div className="card" style={{ backgroundColor: 'var(--bg-elevated)', borderColor: '#38bdf8' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <div style={{ width: '44px', height: '44px', borderRadius: '10px', backgroundColor: 'rgba(16, 185, 129, 0.15)', color: '#34d399', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <div style={{ fontWeight: 800, fontSize: '1.15rem', color: '#f8fafc' }}>
                    Trace Completed: {lastRunResult.program_name}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                    PID {lastRunResult.summary.pid} &bull; Trace ID: {lastRunResult.trace_id}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>CALLS OBSERVED</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, fontFamily: 'var(--font-mono)', color: '#38bdf8' }}>
                    {lastRunResult.summary.total_calls}
                  </div>
                </div>

                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>FAILED CALLS</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, fontFamily: 'var(--font-mono)', color: lastRunResult.summary.failed_calls > 0 ? '#fb7185' : '#34d399' }}>
                    {lastRunResult.summary.failed_calls}
                  </div>
                </div>

                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>DURATION</div>
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, fontFamily: 'var(--font-mono)', color: '#fbbf24' }}>
                    {lastRunResult.summary.duration_sec.toFixed(4)}s
                  </div>
                </div>

                <button className="btn btn-primary" onClick={() => onNavigate('explorer')}>
                  <span>Inspect in Explorer</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          </div>

          {/* Output & Terminal Tabs */}
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '12px' }}>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  className={`btn ${activeTab === 'output' ? 'btn-secondary' : 'btn-outline'}`}
                  style={{ borderColor: activeTab === 'output' ? '#38bdf8' : 'transparent', fontSize: '0.82rem' }}
                  onClick={() => setActiveTab('output')}
                >
                  <Cpu size={14} />
                  <span>Target Process Output</span>
                </button>
                <button
                  className={`btn ${activeTab === 'terminal' ? 'btn-secondary' : 'btn-outline'}`}
                  style={{ borderColor: activeTab === 'terminal' ? '#38bdf8' : 'transparent', fontSize: '0.82rem' }}
                  onClick={() => setActiveTab('terminal')}
                >
                  <Terminal size={14} />
                  <span>Authentic C Tracer Terminal Report</span>
                </button>
              </div>

              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                Exit Code: {lastRunResult.summary.exit_code ?? 0} &bull; Status: {lastRunResult.summary.status}
              </div>
            </div>

            {activeTab === 'output' ? (
              <div className="terminal-window">
                <div className="terminal-header">
                  <div className="terminal-buttons">
                    <span className="term-btn term-close" />
                    <span className="term-btn term-min" />
                    <span className="term-btn term-max" />
                  </div>
                  <div className="terminal-title">STDOUT & STDERR (PID {lastRunResult.summary.pid})</div>
                  <div />
                </div>
                <div className="terminal-body" style={{ color: '#34d399' }}>
                  {lastRunResult.child_output.trim() || '[Process completed without printing to stdout/stderr]'}
                </div>
              </div>
            ) : (
              <div className="terminal-window">
                <div className="terminal-header">
                  <div className="terminal-buttons">
                    <span className="term-btn term-close" />
                    <span className="term-btn term-min" />
                    <span className="term-btn term-max" />
                  </div>
                  <div className="terminal-title">C TRACER TERMINAL FORMAT (ptrace TRACESYSGOOD)</div>
                  <div />
                </div>
                <div className="terminal-body">
                  {lastRunResult.terminal_report}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
