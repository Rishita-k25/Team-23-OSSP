import React, { useState } from 'react';
import { 
  FileClock, 
  Search, 
  Download, 
  Eye, 
  Trash2, 
  Info,
  Calendar,
  Layers,
  FileSpreadsheet,
  FileCode
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { getExportCsvUrl, getExportJsonlUrl } from '../services/api';

export default function HistoryPage({ history, onSelectTrace, onNavigate }) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredHistory = (history || []).filter((item) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      item.program_name.toLowerCase().includes(term) ||
      item.trace_id.toLowerCase().includes(term) ||
      item.program_id.toLowerCase().includes(term)
    );
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Top Banner & Info */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <div className="card-title">
              <FileClock size={18} style={{ color: '#38bdf8' }} />
              <span>Trace History & Stored Reports</span>
            </div>
            <div className="card-subtitle">
              Persisted trace sessions saved in the backend storage directory
            </div>
          </div>

          <div style={{ position: 'relative', width: '280px' }}>
            <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)' }} />
            <input
              type="text"
              className="input-field"
              placeholder="Search history by name or ID..."
              style={{ width: '100%', paddingLeft: '36px', fontSize: '0.82rem' }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div style={{ marginTop: '16px', padding: '12px 16px', backgroundColor: 'var(--bg-input)', borderRadius: '8px', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Info size={16} style={{ color: '#38bdf8', flexShrink: 0 }} />
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            <strong>Persistence Note:</strong> Trace sessions are permanently indexed on disk in <code className="font-mono" style={{ color: '#38bdf8' }}>./traces/</code> as structured JSON, raw JSONL, and isolated child stdout files. Reports can be exported or reloaded at any time.
          </div>
        </div>
      </div>

      {/* History Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Program</th>
              <th>Trace ID</th>
              <th>Timestamp</th>
              <th>Calls</th>
              <th>Errors</th>
              <th>Duration</th>
              <th>Status</th>
              <th style={{ textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredHistory.length > 0 ? (
              filteredHistory.map((item) => (
                <tr key={item.trace_id}>
                  <td>
                    <div style={{ fontWeight: 700, color: 'var(--text-main)' }}>
                      {item.program_name}
                    </div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-dim)' }}>
                      {item.program_id}
                    </div>
                  </td>
                  <td className="font-mono" style={{ fontSize: '0.78rem', color: '#38bdf8' }}>
                    {item.trace_id}
                  </td>
                  <td style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    {item.timestamp ? new Date(item.timestamp).toLocaleString() : 'Recent'}
                  </td>
                  <td className="font-mono" style={{ fontWeight: 600 }}>
                    {item.total_calls}
                  </td>
                  <td className="font-mono" style={{ color: item.failed_calls > 0 ? '#fb7185' : 'var(--text-muted)' }}>
                    {item.failed_calls}
                  </td>
                  <td className="font-mono" style={{ color: '#fbbf24' }}>
                    {item.duration_sec.toFixed(4)}s
                  </td>
                  <td>
                    <StatusBadge status={item.status} />
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '6px' }}>
                      <button
                        className="btn btn-secondary"
                        style={{ padding: '6px 10px', fontSize: '0.78rem' }}
                        title="Inspect in Explorer & Analytics"
                        onClick={() => {
                          onSelectTrace(item.trace_id);
                          onNavigate('explorer');
                        }}
                      >
                        <Eye size={13} />
                        <span>Inspect</span>
                      </button>

                      <a
                        href={getExportCsvUrl(item.trace_id)}
                        className="btn btn-outline"
                        style={{ padding: '6px 10px', fontSize: '0.78rem' }}
                        title="Export CSV"
                        download
                      >
                        <FileSpreadsheet size={13} />
                        <span>CSV</span>
                      </a>

                      <a
                        href={getExportJsonlUrl(item.trace_id)}
                        className="btn btn-outline"
                        style={{ padding: '6px 10px', fontSize: '0.78rem' }}
                        title="Export JSONL"
                        download
                      >
                        <FileCode size={13} />
                        <span>JSONL</span>
                      </a>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
                  No trace runs found matching your search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
