import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';
import { BarChart3, PieChart as PieIcon, Clock, CheckCircle2, XCircle, Info } from 'lucide-react';

const COLORS = ['#0284c7', '#38bdf8', '#818cf8', '#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

export default function AnalyticsPage({ currentTrace, onNavigate }) {
  if (!currentTrace) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '64px 20px' }}>
        <BarChart3 size={48} style={{ color: '#38bdf8', opacity: 0.4, margin: '0 auto 16px' }} />
        <h3 style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: '8px' }}>No Active Trace Data</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', maxWidth: '480px', margin: '0 auto 20px' }}>
          Please run a trace to view real-time graphical metrics, frequency distribution, and return status analytics.
        </p>
        <button className="btn btn-primary" onClick={() => onNavigate('run')}>
          Launch a Trace
        </button>
      </div>
    );
  }

  const { summary, top_syscalls = [], records = [] } = currentTrace;

  // Prepare Pie Chart data: Success vs Error
  const statusPieData = [
    { name: 'Successful Calls', value: summary.successful_calls, color: '#10b981' },
    { name: 'Failed Calls (errno)', value: summary.failed_calls, color: '#f43f5e' },
  ];

  // Frequency Data for BarChart
  const barData = top_syscalls.map((item) => ({
    name: item.name,
    count: item.count,
    percentage: item.percentage,
  }));

  // Average duration per syscall type (in microseconds)
  const durationMap = {};
  records.forEach((r) => {
    if (!durationMap[r.name]) {
      durationMap[r.name] = { totalNs: 0, count: 0 };
    }
    durationMap[r.name].totalNs += r.duration_ns;
    durationMap[r.name].count += 1;
  });

  const durationData = Object.entries(durationMap)
    .map(([name, data]) => ({
      name,
      avgUs: Number((data.totalNs / (data.count || 1) / 1000).toFixed(1)),
      count: data.count,
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const customTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div style={{ backgroundColor: '#0b1329', border: '1px solid #1e315b', padding: '8px 12px', borderRadius: '8px', fontSize: '0.8rem', fontFamily: 'var(--font-mono)' }}>
          <div style={{ color: '#38bdf8', fontWeight: 700 }}>{label}</div>
          <div style={{ color: '#f1f5f9' }}>{payload[0].name}: {payload[0].value}</div>
        </div>
      );
    }
    return null;
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Analytics Header Metrics */}
      <div className="grid-kpi">
        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-title">Active Program</span>
            <div className="kpi-icon"><BarChart3 size={18} /></div>
          </div>
          <div className="kpi-value" style={{ fontSize: '1.4rem' }}>{currentTrace.program_name}</div>
          <div className="kpi-desc">PID {summary.pid} &bull; {summary.total_calls} total calls</div>
        </div>

        <div className="kpi-card success">
          <div className="kpi-header">
            <span className="kpi-title">Success Rate</span>
            <div className="kpi-icon" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', color: '#10b981' }}><CheckCircle2 size={18} /></div>
          </div>
          <div className="kpi-value" style={{ color: '#34d399' }}>
            {summary.total_calls > 0 ? ((summary.successful_calls / summary.total_calls) * 100).toFixed(1) : 0}%
          </div>
          <div className="kpi-desc">{summary.successful_calls} successful returns</div>
        </div>

        <div className="kpi-card danger">
          <div className="kpi-header">
            <span className="kpi-title">Failure Rate</span>
            <div className="kpi-icon" style={{ backgroundColor: 'rgba(244, 63, 94, 0.1)', color: '#f43f5e' }}><XCircle size={18} /></div>
          </div>
          <div className="kpi-value" style={{ color: '#fb7185' }}>{summary.error_rate_percent}%</div>
          <div className="kpi-desc">{summary.failed_calls} errno returns</div>
        </div>

        <div className="kpi-card warning">
          <div className="kpi-header">
            <span className="kpi-title">Wall Time</span>
            <div className="kpi-icon" style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)', color: '#f59e0b' }}><Clock size={18} /></div>
          </div>
          <div className="kpi-value" style={{ color: '#fbbf24' }}>{summary.duration_sec.toFixed(4)}s</div>
          <div className="kpi-desc">Total clock_gettime elapsed</div>
        </div>
      </div>

      {/* Charts Section */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '24px' }}>
        {/* Bar Chart: Frequency */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">
                <BarChart3 size={18} style={{ color: '#38bdf8' }} />
                <span>System Call Frequency by Name</span>
              </div>
              <div className="card-subtitle">Exact occurrence count of top system calls</div>
            </div>
          </div>

          <div style={{ width: '100%', height: 320 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} margin={{ top: 20, right: 20, left: -10, bottom: 20 }}>
                <XAxis 
                  dataKey="name" 
                  stroke="#64748b" 
                  fontSize={12} 
                  fontFamily="var(--font-mono)"
                  tickLine={false}
                />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={12} 
                  fontFamily="var(--font-mono)"
                  tickLine={false}
                />
                <Tooltip content={customTooltip} />
                <Bar dataKey="count" fill="#38bdf8" radius={[4, 4, 0, 0]} name="Observed Count" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart: Status Breakdown */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">
                <PieIcon size={18} style={{ color: '#10b981' }} />
                <span>Success vs. Error Ratio</span>
              </div>
              <div className="card-subtitle">Kernel trap return codes</div>
            </div>
          </div>

          <div style={{ width: '100%', height: 320 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusPieData}
                  cx="50%"
                  cy="45%"
                  innerRadius={65}
                  outerRadius={95}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={customTooltip} />
                <Legend 
                  verticalAlign="bottom" 
                  height={36} 
                  wrapperStyle={{ fontSize: '0.82rem', fontFamily: 'var(--font-mono)' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Duration Distribution Table */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">
              <Clock size={18} style={{ color: '#fbbf24' }} />
              <span>Observed Syscall Durations (Entry to Exit)</span>
            </div>
            <div className="card-subtitle">
              Calculated using monotonic clock timestamps between PTRACE_SYSCALL entry and exit traps
            </div>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>System Call</th>
                <th>Observed Invocations</th>
                <th>Average Duration (µs)</th>
                <th>Cumulative Share</th>
              </tr>
            </thead>
            <tbody>
              {durationData.map((item) => {
                const pct = ((item.count / (summary.total_calls || 1)) * 100).toFixed(1);
                return (
                  <tr key={item.name}>
                    <td className="font-mono" style={{ fontWeight: 700, color: '#38bdf8' }}>
                      {item.name}()
                    </td>
                    <td className="font-mono">{item.count}</td>
                    <td className="font-mono" style={{ color: '#fbbf24' }}>{item.avgUs} µs</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div style={{ width: '120px', height: '6px', backgroundColor: 'var(--bg-input)', borderRadius: '3px', overflow: 'hidden' }}>
                          <div style={{ width: `${pct}%`, height: '100%', backgroundColor: '#38bdf8' }} />
                        </div>
                        <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{pct}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
