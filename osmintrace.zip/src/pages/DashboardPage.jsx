import React, { useState } from 'react';
import { 
  Activity, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Cpu, 
  Terminal, 
  Play, 
  ArrowRight,
  TrendingUp,
  BarChart2,
  FileCode,
  Loader2,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

export default function DashboardPage({ 
  health, 
  currentTrace, 
  history, 
  programs = [],
  onRunTrace,
  loadingTrace = false,
  traceError = null,
  onNavigate, 
  onSelectTrace,
  onRefresh
}) {
  const [quickProgId, setQuickProgId] = useState('hello_world');
  const summary = currentTrace?.summary;
  const topCalls = currentTrace?.top_syscalls || [];

  const handleQuickRun = () => {
    if (onRunTrace) {
      onRunTrace(quickProgId || 'hello_world');
    } else {
      onNavigate('run');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      {/* Backend Disconnected Warning */}
      {!health && (
        <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', padding: '14px 18px', borderRadius: '10px', color: '#f87171', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <AlertTriangle size={18} />
            <span style={{ fontSize: '0.88rem' }}>
              <strong>SysTrace backend is not connected.</strong> Ensure the FastAPI server is running with <code className="font-mono" style={{ color: '#38bdf8' }}>python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000</code>.
            </span>
          </div>
          {onRefresh && (
            <button className="btn btn-outline" style={{ padding: '6px 12px', fontSize: '0.8rem', borderColor: '#f87171', color: '#f87171' }} onClick={onRefresh}>
              <RefreshCw size={14} /> Retry Connection
            </button>
          )}
        </div>
      )}

      {/* Trace Error Notification */}
      {traceError && (
        <div style={{ backgroundColor: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '14px 18px', borderRadius: '10px', color: '#fb7185', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <AlertTriangle size={18} />
          <div style={{ fontSize: '0.86rem' }}>{traceError}</div>
        </div>
      )}

      {/* Banner / Overview */}
      <div className="card" style={{ background: 'linear-gradient(135deg, rgba(14, 28, 56, 0.9), rgba(11, 19, 41, 0.95))', borderColor: 'rgba(56, 189, 248, 0.3)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '20px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
              <span className="badge badge-cyan">Operating Systems Lab Demonstration</span>
              <span className="badge badge-success">x86-64 Linux ptrace()</span>
            </div>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 800, letterSpacing: '-0.5px', marginBottom: '6px' }}>
              SysTrace — Real Linux Process System-Call Monitor
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', maxWidth: '750px', lineHeight: 1.5 }}>
              A full-stack diagnostic utility combining an authentic C tracing engine compiled under Ubuntu GCC, 
              real-time <code className="font-mono" style={{ color: '#38bdf8' }}>PTRACE_SYSCALL</code> trap inspection, 
              and an interactive telemetry dashboard.
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
            <button 
              className="btn btn-primary" 
              onClick={handleQuickRun}
              disabled={loadingTrace || !health?.tracer_available}
            >
              {loadingTrace ? (
                <>
                  <Loader2 size={16} className="spin" style={{ animation: 'spin 1s linear infinite' }} />
                  <span>Tracing Syscalls...</span>
                </>
              ) : (
                <>
                  <Play size={16} fill="currentColor" />
                  <span>Run Trace</span>
                </>
              )}
            </button>
            <button className="btn btn-outline" onClick={() => onNavigate('run')}>
              <span>Configure Trace</span>
              <ArrowRight size={14} />
            </button>
            <button className="btn btn-secondary" onClick={() => onNavigate('about')}>
              <FileCode size={16} />
              <span>Viva & Docs</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid-kpi">
        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-title">Total System Calls</span>
            <div className="kpi-icon">
              <Activity size={18} />
            </div>
          </div>
          <div className="kpi-value">{summary ? summary.total_calls : '—'}</div>
          <div className="kpi-desc">
            {summary ? `Observed across PID ${summary.pid}` : 'No active trace executed'}
          </div>
        </div>

        <div className="kpi-card success">
          <div className="kpi-header">
            <span className="kpi-title">Successful Calls</span>
            <div className="kpi-icon" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', color: '#10b981' }}>
              <CheckCircle2 size={18} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#34d399' }}>
            {summary ? summary.successful_calls : '—'}
          </div>
          <div className="kpi-desc">
            {summary ? `${((summary.successful_calls / (summary.total_calls || 1)) * 100).toFixed(1)}% success rate` : 'Awaiting trace'}
          </div>
        </div>

        <div className="kpi-card danger">
          <div className="kpi-header">
            <span className="kpi-title">Failed / Error Calls</span>
            <div className="kpi-icon" style={{ backgroundColor: 'rgba(244, 63, 94, 0.1)', color: '#f43f5e' }}>
              <XCircle size={18} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#fb7185' }}>
            {summary ? summary.failed_calls : '—'}
          </div>
          <div className="kpi-desc">
            {summary ? `${summary.error_rate_percent}% errno error returns` : 'Awaiting trace'}
          </div>
        </div>

        <div className="kpi-card warning">
          <div className="kpi-header">
            <span className="kpi-title">Elapsed Time</span>
            <div className="kpi-icon" style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)', color: '#f59e0b' }}>
              <Clock size={18} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#fbbf24' }}>
            {summary ? `${summary.duration_sec.toFixed(4)}s` : '—'}
          </div>
          <div className="kpi-desc">
            {summary ? `Status: ${summary.status} (exit ${summary.exit_code ?? 0})` : 'Awaiting trace'}
          </div>
        </div>
      </div>

      {/* Main Grid: Syscall Frequency & Recent Traces */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '24px' }}>
        {/* Frequency by Syscall Name */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">
                <BarChart2 size={18} style={{ color: '#38bdf8' }} />
                <span>Syscall Frequency Distribution</span>
              </div>
              <div className="card-subtitle">
                {currentTrace ? `Breakdown for ${currentTrace.program_name}` : 'Calculated from captured execution'}
              </div>
            </div>
            {currentTrace && (
              <button className="btn btn-outline" style={{ fontSize: '0.78rem', padding: '6px 12px' }} onClick={() => onNavigate('analytics')}>
                View Full Analytics <ArrowRight size={14} />
              </button>
            )}
          </div>

          {topCalls.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginTop: '10px' }}>
              {topCalls.map((item) => (
                <div key={item.name}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.84rem', marginBottom: '6px' }}>
                    <span className="font-mono" style={{ fontWeight: 600, color: '#38bdf8' }}>{item.name}</span>
                    <span style={{ color: 'var(--text-muted)' }}>
                      {item.count} calls <span style={{ color: 'var(--text-dim)' }}>({item.percentage}%)</span>
                    </span>
                  </div>
                  <div style={{ width: '100%', height: '8px', backgroundColor: 'var(--bg-input)', borderRadius: '4px', overflow: 'hidden' }}>
                    <div 
                      style={{ 
                        width: `${item.percentage}%`, 
                        height: '100%', 
                        background: 'linear-gradient(90deg, #0284c7, #38bdf8)',
                        borderRadius: '4px',
                        transition: 'width 0.4s ease'
                      }} 
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
              <Cpu size={40} style={{ opacity: 0.3, marginBottom: '12px' }} />
              <div style={{ fontWeight: 600 }}>No Syscall Telemetry Available</div>
              <p style={{ fontSize: '0.82rem', marginTop: '4px' }}>Run an approved test program to capture live system call telemetry.</p>
              <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginTop: '16px' }}>
                <button 
                  className="btn btn-primary" 
                  onClick={handleQuickRun}
                  disabled={loadingTrace || !health?.tracer_available}
                >
                  {loadingTrace ? (
                    <>
                      <Loader2 size={14} className="spin" style={{ animation: 'spin 1s linear infinite' }} />
                      <span>Tracing Syscalls...</span>
                    </>
                  ) : (
                    <>
                      <Play size={14} fill="currentColor" />
                      <span>Run Trace (Hello World)</span>
                    </>
                  )}
                </button>
                <button className="btn btn-secondary" onClick={() => onNavigate('run')}>
                  <span>Select Another Program</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Recent Trace Runs */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">
                <Terminal size={18} style={{ color: '#10b981' }} />
                <span>Recent Traces</span>
              </div>
              <div className="card-subtitle">Stored backend sessions</div>
            </div>
            <button className="btn btn-outline" style={{ fontSize: '0.78rem', padding: '6px 12px' }} onClick={() => onNavigate('history')}>
              All History <ArrowRight size={14} />
            </button>
          </div>

          {history && history.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {history.slice(0, 5).map((t) => (
                <div 
                  key={t.trace_id} 
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'space-between',
                    padding: '12px 14px',
                    borderRadius: '8px',
                    backgroundColor: 'var(--bg-input)',
                    border: '1px solid var(--border-subtle)',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                  onClick={() => onSelectTrace(t.trace_id)}
                >
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.88rem', color: 'var(--text-main)' }}>
                      {t.program_name}
                    </div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)' }}>
                      {t.trace_id.slice(0, 24)}...
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '0.82rem', fontWeight: 600, color: '#38bdf8' }}>
                        {t.total_calls} calls
                      </div>
                      <div style={{ fontSize: '0.72rem', color: t.failed_calls > 0 ? '#fb7185' : 'var(--text-dim)' }}>
                        {t.failed_calls} failed &bull; {t.duration_sec.toFixed(3)}s
                      </div>
                    </div>
                    <StatusBadge status={t.status} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
              <Clock size={40} style={{ opacity: 0.3, marginBottom: '12px' }} />
              <div style={{ fontWeight: 600 }}>No Trace History Yet</div>
              <p style={{ fontSize: '0.82rem', marginTop: '4px' }}>Traces run from the web dashboard will be safely indexed and persisted here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
