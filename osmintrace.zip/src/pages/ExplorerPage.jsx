import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  Cpu, 
  ExternalLink,
  Layers
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import SyscallDetailModal from '../components/SyscallDetailModal';
import { getExportCsvUrl, getExportJsonlUrl } from '../services/api';

export default function ExplorerPage({ currentTrace, onNavigate }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all'); // all, success, error, unknown
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const records = currentTrace?.records || [];

  // Filter and search logic
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      // Type filter
      if (filterType === 'success' && r.is_error) return false;
      if (filterType === 'error' && !r.is_error) return false;
      if (filterType === 'unknown' && r.name !== 'unknown') return false;

      // Text search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = r.name.toLowerCase().includes(q);
        const matchesNr = r.syscall_nr.toString().includes(q);
        const matchesRetval = r.retval.toString().includes(q);
        const matchesPid = r.pid.toString().includes(q);
        return matchesName || matchesNr || matchesRetval || matchesPid;
      }
      return true;
    });
  }, [records, filterType, searchQuery]);

  // Pagination
  const totalPages = Math.ceil(filteredRecords.length / pageSize) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredRecords.slice(start, start + pageSize);
  }, [filteredRecords, page, pageSize]);

  if (!currentTrace) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '64px 20px' }}>
        <Cpu size={48} style={{ color: '#38bdf8', opacity: 0.4, margin: '0 auto 16px' }} />
        <h3 style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: '8px' }}>No Active Trace Selected</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', maxWidth: '480px', margin: '0 auto 20px' }}>
          Execute a test program or select an existing session from Trace History to inspect real x86-64 system call registers.
        </p>
        <button className="btn btn-primary" onClick={() => onNavigate('run')}>
          Go to Run Trace
        </button>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Search and Filter Toolbar */}
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          {/* Search Box */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, minWidth: '240px', maxWidth: '420px' }}>
            <div style={{ position: 'relative', width: '100%' }}>
              <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-dim)' }} />
              <input
                type="text"
                className="input-field"
                placeholder="Search syscall name, number, or return code..."
                style={{ width: '100%', paddingLeft: '38px' }}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setPage(1);
                }}
              />
            </div>
          </div>

          {/* Filter Pills */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 600 }}>Filter:</span>
            {[
              { id: 'all', label: `All (${records.length})` },
              { id: 'success', label: `Success (${records.filter((r) => !r.is_error).length})` },
              { id: 'error', label: `Errors (${records.filter((r) => r.is_error).length})` },
              { id: 'unknown', label: `Unknown (${records.filter((r) => r.name === 'unknown').length})` },
            ].map((f) => (
              <button
                key={f.id}
                className={`btn ${filterType === f.id ? 'btn-secondary' : 'btn-outline'}`}
                style={{ 
                  fontSize: '0.78rem', 
                  padding: '6px 12px', 
                  borderColor: filterType === f.id ? '#38bdf8' : 'var(--border-subtle)',
                  color: filterType === f.id ? '#38bdf8' : 'var(--text-muted)'
                }}
                onClick={() => {
                  setFilterType(f.id);
                  setPage(1);
                }}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Export Actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <a
              href={getExportCsvUrl(currentTrace.trace_id)}
              className="btn btn-outline"
              style={{ fontSize: '0.78rem', padding: '6px 12px' }}
              download
            >
              <Download size={14} />
              <span>CSV</span>
            </a>
            <a
              href={getExportJsonlUrl(currentTrace.trace_id)}
              className="btn btn-outline"
              style={{ fontSize: '0.78rem', padding: '6px 12px' }}
              download
            >
              <Download size={14} />
              <span>JSONL</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th style={{ width: '50px' }}>#</th>
              <th>PID</th>
              <th>Syscall Name</th>
              <th>NR</th>
              <th>Arg 0 (rdi)</th>
              <th>Arg 1 (rsi)</th>
              <th>Arg 2 (rdx)</th>
              <th>Return Value (rax)</th>
              <th>Status</th>
              <th>Duration (µs)</th>
              <th style={{ textAlign: 'center' }}>Inspect</th>
            </tr>
          </thead>
          <tbody>
            {paginatedRecords.length > 0 ? (
              paginatedRecords.map((r) => {
                const args = r.args || [];
                const fmtArg = (val) => {
                  if (val === undefined || val === 0) return '0x0';
                  return '0x' + (Number(val) >>> 0).toString(16);
                };
                return (
                  <tr 
                    key={r.index} 
                    className="clickable"
                    onClick={() => setSelectedRecord(r)}
                  >
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-dim)' }}>{r.index}</td>
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{r.pid}</td>
                    <td>
                      <span className="font-mono" style={{ fontWeight: 700, color: '#38bdf8' }}>
                        {r.name}
                      </span>
                    </td>
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{r.syscall_nr}</td>
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-dim)', fontSize: '0.78rem' }}>
                      {fmtArg(args[0])}
                    </td>
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-dim)', fontSize: '0.78rem' }}>
                      {fmtArg(args[1])}
                    </td>
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-dim)', fontSize: '0.78rem' }}>
                      {fmtArg(args[2])}
                    </td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: r.is_error ? '#fb7185' : '#34d399' }}>
                      {r.retval}
                    </td>
                    <td>
                      <StatusBadge isError={r.is_error} />
                    </td>
                    <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                      {(r.duration_ns / 1000).toFixed(1)}
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <span style={{ color: '#38bdf8', opacity: 0.8 }}>
                        <ExternalLink size={14} />
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={11} style={{ textAlign: 'center', padding: '36px', color: 'var(--text-muted)' }}>
                  No system calls match the current search query or filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 4px' }}>
        <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
          Showing {filteredRecords.length > 0 ? (page - 1) * pageSize + 1 : 0} to {Math.min(page * pageSize, filteredRecords.length)} of {filteredRecords.length} records
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <select 
            className="select-field" 
            style={{ padding: '4px 10px', fontSize: '0.8rem' }}
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
          >
            <option value={15}>15 per page</option>
            <option value={25}>25 per page</option>
            <option value={50}>50 per page</option>
            <option value={100}>100 per page</option>
          </select>

          <button
            className="btn btn-outline"
            style={{ padding: '6px 10px' }}
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            <ChevronLeft size={16} />
          </button>

          <span style={{ fontSize: '0.82rem', fontFamily: 'var(--font-mono)', padding: '0 6px' }}>
            {page} / {totalPages}
          </span>

          <button
            className="btn btn-outline"
            style={{ padding: '6px 10px' }}
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedRecord && (
        <SyscallDetailModal
          record={selectedRecord}
          onClose={() => setSelectedRecord(null)}
        />
      )}
    </div>
  );
}
