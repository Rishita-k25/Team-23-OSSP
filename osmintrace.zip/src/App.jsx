import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import DashboardPage from './pages/DashboardPage';
import RunTracePage from './pages/RunTracePage';
import ExplorerPage from './pages/ExplorerPage';
import AnalyticsPage from './pages/AnalyticsPage';
import HistoryPage from './pages/HistoryPage';
import AboutPage from './pages/AboutPage';

import { 
  fetchHealth, 
  fetchPrograms, 
  fetchTraces, 
  fetchTrace, 
  startTrace 
} from './services/api';

export default function App() {
  const [activePage, setActivePage] = useState('dashboard');
  const [health, setHealth] = useState(null);
  const [programs, setPrograms] = useState([]);
  const [history, setHistory] = useState([]);
  const [currentTrace, setCurrentTrace] = useState(null);
  const [loadingTrace, setLoadingTrace] = useState(false);
  const [traceError, setTraceError] = useState(null);

  // Load initial environment & telemetry
  const loadInitialData = async () => {
    try {
      const [h, progs, hist] = await Promise.all([
        fetchHealth().catch(() => null),
        fetchPrograms().catch(() => []),
        fetchTraces().catch(() => []),
      ]);
      setHealth(h);
      setPrograms(progs);
      setHistory(hist);

      // If history exists, load the most recent trace into current state
      if (hist && hist.length > 0 && !currentTrace) {
        const latestTrace = await fetchTrace(hist[0].trace_id).catch(() => null);
        if (latestTrace) {
          setCurrentTrace(latestTrace);
        }
      }
    } catch (err) {
      console.error("Initialization error:", err);
    }
  };

  useEffect(() => {
    loadInitialData();

    // Auto-reconnect poll every 3 seconds if backend is not yet reachable
    const interval = setInterval(() => {
      if (!health) {
        loadInitialData();
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [health, currentTrace]);

  // Handler to execute a real trace
  const handleRunTrace = async (progId) => {
    setLoadingTrace(true);
    setTraceError(null);
    try {
      const result = await startTrace(progId);
      setCurrentTrace(result);
      // Refresh history & health
      const [updatedHistory, updatedHealth] = await Promise.all([
        fetchTraces().catch(() => history),
        fetchHealth().catch(() => health),
      ]);
      setHistory(updatedHistory);
      if (updatedHealth) setHealth(updatedHealth);
      return result;
    } catch (err) {
      setTraceError(err.message || 'Trace failed to execute');
      throw err;
    } finally {
      setLoadingTrace(false);
    }
  };

  // Handler to select a past trace
  const handleSelectTrace = async (traceId) => {
    try {
      const trace = await fetchTrace(traceId);
      setCurrentTrace(trace);
    } catch (err) {
      console.error("Failed to select trace:", err);
    }
  };

  return (
    <div className="app-container">
      <Sidebar 
        activePage={activePage} 
        setActivePage={setActivePage} 
        health={health} 
      />

      <div className="main-layout">
        <Navbar 
          activePage={activePage} 
          currentTrace={currentTrace}
          onStartTraceClick={() => setActivePage('run')}
        />

        <main className="content-body">
          {activePage === 'dashboard' && (
            <DashboardPage
              health={health}
              currentTrace={currentTrace}
              history={history}
              programs={programs}
              onRunTrace={handleRunTrace}
              loadingTrace={loadingTrace}
              traceError={traceError}
              onNavigate={setActivePage}
              onSelectTrace={handleSelectTrace}
              onRefresh={loadInitialData}
            />
          )}

          {activePage === 'run' && (
            <RunTracePage
              health={health}
              programs={programs}
              onRunTrace={handleRunTrace}
              loading={loadingTrace}
              error={traceError}
              lastRunResult={currentTrace}
              onNavigate={setActivePage}
              onRefresh={loadInitialData}
            />
          )}

          {activePage === 'explorer' && (
            <ExplorerPage
              currentTrace={currentTrace}
              onNavigate={setActivePage}
            />
          )}

          {activePage === 'analytics' && (
            <AnalyticsPage
              currentTrace={currentTrace}
              onNavigate={setActivePage}
            />
          )}

          {activePage === 'history' && (
            <HistoryPage
              history={history}
              onSelectTrace={handleSelectTrace}
              onNavigate={setActivePage}
            />
          )}

          {activePage === 'about' && (
            <AboutPage />
          )}
        </main>
      </div>
    </div>
  );
}
